=============================
|     L3   Groupe   4.1     |
=============================
|  Elie ROCHE  |  Evan RIO  |
=============================
|      Compilateur  V2      |
=============================

Un des problèmes rencontré concerne les BINCONDS, qui une fois dans un context local ne marche plus de la bonne manière.
Ont à eu du mal avec la gestion des contenu , affect.


!! PLACEHOLDER !!
Rendu en tant que PLACEHOLDER
